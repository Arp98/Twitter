from django.shortcuts import render, redirect
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required
from .models import Tweets
from django.contrib import messages
from Account.models import Account
from django.core.paginator import Paginator


@login_required(login_url='/')
def Dashboard(request):
    # will give us the email because we have changed the username to email in our custom model.
    user_email = request.user.get_username()
    paginate_by = 5

    user_Tweet = Tweets.objects.filter(Tweet_User=user_email).order_by('-Tweet_Timestamps')
    if len(user_Tweet) == 0:
        messages.success(request, 'No tweet yet!!! Please post a Tweet first.')
        return redirect('/Dashboard/NewTweet')
    user_name = Account.objects.get(email=user_email).name
    paginator = Paginator(user_Tweet, paginate_by)  # Show 5 Tweet per page.
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, 'Dashboard.html', {'user_name': user_name, 'page_obj': page_obj})


@login_required(login_url='/')
def new_Tweet(request):
    if request.method == 'POST':
        Tweet_User = request.user.get_username()
        Tweet = request.POST['Tweet']
        Tweets.objects.create(Tweet_User=Tweet_User, Tweet=Tweet)
        messages.success(request, 'Tweet Successfully Saved')
        return redirect('/Dashboard/NewTweet')

    else:
        return render(request, 'New_Tweet.html')


@login_required(login_url='/')
def logoutuser(request):
    logout(request)
    return redirect('/')
