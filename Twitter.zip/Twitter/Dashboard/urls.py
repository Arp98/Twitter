from django.urls import path
from . import views

urlpatterns = [
    path('NewTweet', views.new_Tweet, name="New Tweet"),
    path('Dashboard', views.Dashboard, name="Dashboard"),
    path('Logout', views.logoutuser, name='Logout')
]
