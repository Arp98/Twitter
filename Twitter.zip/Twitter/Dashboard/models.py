from django.db import models
import datetime


class Tweets(models.Model):
    Tweet_User = models.CharField(max_length=100)
    Tweet = models.CharField(max_length=1000, unique=True)
    Tweet_Timestamps = models.DateTimeField(default=datetime.datetime.now)
