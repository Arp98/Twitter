from django.db import models
import datetime
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager


class Account(AbstractBaseUser):
    name = models.CharField(max_length=100)
    email = models.EmailField(max_length=100, unique=True)
    password = models.CharField(max_length=200)
    Timestamps = models.DateTimeField(default=datetime.datetime.now, verbose_name='Timestamps')

    USERNAME_FIELD = 'email'
    last_login = False
    objects = BaseUserManager()
