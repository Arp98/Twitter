from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import CreateUserForms
from .models import Account
from django.contrib.auth import authenticate, login as auth_login
import datetime


def login(request):
    if request.user.is_authenticated:
        return redirect('/Dashboard/Dashboard')
    else:
        if request.method == 'POST':
            email = request.POST['email']
            password = request.POST['password']

            user = authenticate(email=email, password=password)

            if user is not None:
                if user.is_active:
                    auth_login(request, user)
                    return redirect('/Dashboard/Dashboard')
                else:
                    messages.info(request, 'your account has been disabled \n Please login again')
                    return render(request, 'Login.html')
            else:
                messages.info(request, 'Invalid Credentials')
                return render(request, 'Login.html')
        else:
            return render(request, 'Login.html')


def register(request):
    if request.user.is_authenticated:
        return redirect('/Dashboard/Dashboard')
    else:
        if request.method == 'POST':
            form = CreateUserForms(request.POST)

            if form.is_valid():
                email = form.cleaned_data.get('email')
                username = form.cleaned_data.get('name')
                raw_password = form.cleaned_data.get('password1')
                form.save()
                account = authenticate(email=email, password=raw_password)
                auth_login(request, account, backend='django.contrib.auth.backends.ModelBackend')
                messages.success(request, 'Account Successfully created for ' + username)
                return redirect('/')
            else:
                return render(request, 'SignUp.html', {'form': form})

        else:
            form = CreateUserForms()
            return render(request, 'SignUp.html', {'form': form})
